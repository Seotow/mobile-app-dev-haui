package com.example.bai62_64;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_result);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView txtResult=findViewById(R.id.txtResult);
        Button btnBack=findViewById(R.id.btnBack);
        Intent callerIntent=getIntent();
        Bundle getResultfromCaller = callerIntent.getBundleExtra("Main_send");

        float result_salary = getResultfromCaller.getFloat("Salary_send");
        float tax = 0;
        if(result_salary > 1000){
            tax = 0.1f * result_salary;
        }
        txtResult.setText(tax + "");
        btnBack.setOnClickListener(v -> {
            Intent backIntent = new Intent(ResultActivity.this,MainActivity.class);
            startActivity(backIntent);
        });
    }
}