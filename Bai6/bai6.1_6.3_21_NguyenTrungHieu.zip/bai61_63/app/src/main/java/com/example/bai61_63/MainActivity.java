package com.example.bai61_63;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnContext = findViewById(R.id.btn_context);
        registerForContextMenu(btnContext);

        //go activity 2 by intent
        Button btnGo = findViewById(R.id.btn_go);
        btnGo.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity2.class);
            startActivity(intent);
        });
    }

    //create option menu from menu.xml
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //handle action bar item click
        int id = item.getItemId();
        if(id == R.id.mnu_xemds){
            Toast.makeText(this, "Xem danh sách", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_suads){
            Toast.makeText(this, "Sửa danh sách", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_xoads){
            Toast.makeText(this, "Xóa danh sách", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_inbaocao){
            Toast.makeText(this, "In báo cáo", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_introgiup){
            Toast.makeText(this, "Trợ giúp", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_xemdssv){
            Toast.makeText(this, "Sinh viên", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_xemdslophoc){
            Toast.makeText(this, "Lớp học", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);

    }

    //context menu

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        //handle context menu item click
        int id = item.getItemId();
        if(id == R.id.mnu_xemdsKem){
            Toast.makeText(this, "Kem Tràng Tiền", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_xemdsnuocep){
            Toast.makeText(this, "Nước ép hoa quả theo mùa", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_Khaivi){
            Toast.makeText(this, "Món Khai vị", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_Hấp){
            Toast.makeText(this, "Món hấp", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_Chiên){
            Toast.makeText(this, "Món chiên", Toast.LENGTH_SHORT).show();
        } else if(id == R.id.mnu_Salat){
            Toast.makeText(this, "Salat", Toast.LENGTH_SHORT).show();
        }

        return super.onContextItemSelected(item);
    }
}