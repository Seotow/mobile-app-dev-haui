package com.example.bai65;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class InputDataActivity extends AppCompatActivity {
    Button btnSave1, btnSave2;
    EditText etNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_input_data);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnSave1 = findViewById(R.id.btnSave1);
        btnSave2 = findViewById(R.id.btnSave2);
        etNumber = findViewById(R.id.etNumber);

        btnSave1.setOnClickListener(view -> {
            sendToMain(MainActivity.RESULT_CODE_SAVE1);
        });

        btnSave2.setOnClickListener(view -> {
            sendToMain(MainActivity.RESULT_CODE_SAVE2);
        });
    }

    private void sendToMain(int resultCode) {
        Intent intent = getIntent();
        intent.putExtra("data", Integer.parseInt(etNumber.getText().toString()));
        setResult(resultCode, intent);
        finish();
    }
}