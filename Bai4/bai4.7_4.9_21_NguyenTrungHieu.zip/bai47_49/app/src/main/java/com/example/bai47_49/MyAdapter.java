package com.example.bai47_49;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends ArrayAdapter {
    Activity context;
    int layoutID;
    ArrayList<String> list = null;

    public MyAdapter(@NonNull Activity context, int resource, @NonNull List objects) {
        super(context, resource, objects);
        this.context = context;
        this.layoutID = resource;
        this.list = (ArrayList<String>) objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        convertView = inflater.inflate(layoutID, null);
        if((list.size() > 0) && (position >= 0)) {
            final TextView txtStt = convertView.findViewById(R.id.txtStt);
            final TextView txtNoiDung = convertView.findViewById(R.id.txtNoiDung);
            txtStt.setText(position + "");
            txtNoiDung.setText(list.get(position).toString() + "");
        }
        return convertView;
    }
}
