package com.example.bai47_49;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AnalogClock;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class bai49 extends AppCompatActivity {
    Button btnDatePicker, btnTimePicker;
    TextView txtDate;
    LinearLayout mylayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bai49);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        getWidget();
        doWork();
    }

    private void getWidget() {
        btnDatePicker = findViewById(R.id.btnDatePickerDialog);
        btnTimePicker = findViewById(R.id.btnTimePickerDialog);
        txtDate = findViewById(R.id.txtdate);
    }

    private void doWork() {
        btnDatePicker.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DatePickerDialog.OnDateSetListener callback =
                                new DatePickerDialog.OnDateSetListener() {
                                    @Override
                                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                                        txtDate.setText(i2+"/"+i1+"/"+i);
                                    }
                                };
                        DatePickerDialog pic=new DatePickerDialog(bai49.this,callback,2020,11,10);
                        pic.setTitle("my datetime picker");
                        pic.show();
                    }
                });

        btnTimePicker.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        TimePickerDialog.OnTimeSetListener callback =
                                new TimePickerDialog.OnTimeSetListener(){
                                    @Override
                                    public void onTimeSet(TimePicker timePicker,int i, int i1) {
                                        txtDate.setText(i+"-"+i1);
                                    }
                                };
                        TimePickerDialog time=new TimePickerDialog(bai49.this, callback, 11,30,true);
                        time.setTitle("my time picker");
                        time.show();
                    }
                });
    }
}