package com.example.bai47_49;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class bai48 extends AppCompatActivity {

    private EditText etMaNv, etTenNv;
    private RadioGroup rgLoaiNv;
    private CheckBox cbLuuThongTin;
    private Button inputNV;
    private ListView lvNhanVien;
    private ArrayList<Employee> employeeList;
    private MyAdapter48 adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bai48);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText maNv = findViewById(R.id.etMaNv);
        EditText tenNv = findViewById(R.id.etTenNv);
        RadioGroup loaiNv = findViewById(R.id.rgLoaiNv);

        Button inputNV = findViewById(R.id.inputNV);
        CheckBox luuThongTin = findViewById(R.id.cbLuuThongTin);
        ListView lvNhanVien = findViewById(R.id.lvNhanVien);

        employeeList = new ArrayList<>();
        employeeList.add(new EmployeeParttime("Nv1", "Nguyễn Hiếu"));
        employeeList.add(new EmployeeFullTime("Nv2", "Nguyễn Hiếu2"));
        employeeList.add(new EmployeeParttime("Nv3", "Nguyễn Hiếu3"));
        adapter = new MyAdapter48(this, R.layout.myitemlist48, employeeList);
        lvNhanVien.setAdapter(adapter);

        inputNV.setOnClickListener(v -> {
            if(!luuThongTin.isChecked()) { return; }
            String id = maNv.getText().toString();
            String name = tenNv.getText().toString();
            if(id.isEmpty() || name.isEmpty()) { return; }
            if(loaiNv.getCheckedRadioButtonId() == R.id.rbChinhThuc){
                employeeList.add(new EmployeeFullTime(id, name));
            } else {
                employeeList.add(new EmployeeParttime(id, name));
            }
            maNv.setText("");
            tenNv.setText("");
            adapter.notifyDataSetChanged();

        });
    }
}