package com.example.bai47_49;

import android.app.Activity;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyAdapter48 extends ArrayAdapter {
    Activity context;
    int layoutID;
    ArrayList<Employee> list = null;

    public MyAdapter48(Activity context, int resource, ArrayList<Employee> objects) {
        super(context, resource, objects);
        this.context = context;
        this.layoutID = resource;
        this.list = (ArrayList<Employee>) objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        convertView = inflater.inflate(layoutID, null);
        if((list.size() > 0) && (position >= 0)) {
            final TextView txtID = convertView.findViewById(R.id.txtID);
            final TextView txtTen = convertView.findViewById(R.id.txtTen);
            final TextView txtLoai = convertView.findViewById(R.id.txtLoai);
            final TextView txtLuong = convertView.findViewById(R.id.txtLuong);

            txtID.setText("ID: " + list.get(position).getId());
            txtTen.setText("Họ tên: " + list.get(position).getName());
            if(list.get(position) instanceof EmployeeFullTime) {
                txtLoai.setText("Nhân viên thời vụ");
                txtLuong.setText("Mức lương: " + list.get(position).salaryCalc());
            }
            else if(list.get(position) instanceof EmployeeParttime) {
                txtLoai.setText("Nhân viên chính thức");
                txtLuong.setText("Mức lương: " + list.get(position).salaryCalc());
            }
            else {
                txtLoai.setText("Nhân viên chính thức");
                txtLuong.setText("Mức lương: " + list.get(position).salaryCalc());
            }
        }

        if((position + 1) % 2 == 0) {
            convertView.setBackgroundColor(Color.parseColor("#00F000"));
        }
        return convertView;
    }
}
