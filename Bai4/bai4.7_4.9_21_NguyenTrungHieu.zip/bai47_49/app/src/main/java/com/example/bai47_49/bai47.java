package com.example.bai47_49;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class bai47 extends AppCompatActivity {
    EditText txtTen;
    TextView txtSelection;
    Button btnNhap;
    ListView lvPerson;

    ArrayList<String> arrList = null;
    MyAdapter adapter = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bai47);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtTen = findViewById(R.id.editTen);
        txtSelection = findViewById(R.id.txtSelection);
        btnNhap = findViewById(R.id.btnNhap);
        lvPerson = findViewById(R.id.lvPerson);

        arrList = new ArrayList<String>();
        arrList.add("Hà Nội");
        arrList.add("Hải Phòng");
        arrList.add("Huế");
        arrList.add("Đà Nẵng");

        adapter = new MyAdapter(this, R.layout.myitemlist, arrList);
        lvPerson.setAdapter(adapter);

        btnNhap.setOnClickListener(v -> {
            arrList.add(txtTen.getText().toString());
            adapter.notifyDataSetChanged();
            txtTen.setText("");
        });

        lvPerson.setOnItemClickListener((parent, view, position, id) -> {
            txtSelection.setText("Vị trí" + position + "giá trị: " + arrList.get(position));
            txtTen.setText(arrList.get(position));
        });


        lvPerson.setOnItemLongClickListener((parent, view, position, id) -> {
            arrList.remove(position);
            adapter.notifyDataSetChanged();
            return false;
        });
    }
}