package com.example.bai410_412;

import androidx.annotation.NonNull;

public class Product extends Good{
    private int quantity;
    public Product(String id, String name, int quantity) {
        super(id, name);
        this.quantity = quantity;
    }

    public Product() {
        super();
        quantity = 0;
    }

    int getQuantity() {
        return quantity;
    }

    void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @NonNull
    @Override
    public String toString() {
        return super.toString() + " - " + quantity;
    }
}
