package com.example.bai410_412;

import androidx.annotation.NonNull;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class JobInWeek {
    private String title;
    private String desc;
    private Date dateFinish;
    private Date timeFinish;

    public JobInWeek(String title, String desc, Date dateFinish, Date timeFinish) {
        this.title = title;
        this.desc = desc;
        this.dateFinish = dateFinish;
        this.timeFinish = timeFinish;
    }

    public String getTitle() {
        return title;
    }

    public String getDesc() {
        return desc;
    }

    public Date getDateFinish() {
        return dateFinish;
    }

    public Date getTimeFinish() {
        return timeFinish;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setDateFinish(Date dateFinish) {
        this.dateFinish = dateFinish;
    }

    public void setTimeFinish(Date timeFinish) {
        this.timeFinish = timeFinish;
    }

    public String getDateFormat(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        return sdf.format(date);
    }

    public String getHourFormat(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        return sdf.format(date);
    }

    @NonNull
    @Override
    public String toString() {
        return this.title + " - " + getDateFormat(this.dateFinish) + " - " + getHourFormat(this.timeFinish);
    }
}
