package com.example.bai410_412;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class bai412 extends AppCompatActivity {
    TextView tvNgayHT, tvGioHT;
    EditText etCongViec, etNoiDung;
    Button btnDate, btnTime, btnNhap;

    ArrayList<JobInWeek> arrayJob = new ArrayList<>();
    ArrayAdapter<JobInWeek> adapterJob = null;
    ListView lvCongViec;
    Calendar cal;
    Date dateFinish;
    Date timeFinish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bai412);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        getFormWidget();
        getDefaultInfor();
        addEventFormWidgets();

    }

    private void getFormWidget(){
        // Get all from view
        tvNgayHT = findViewById(R.id.tvNgayHT);
        tvGioHT = findViewById(R.id.tvGioHT);
        etCongViec = findViewById(R.id.etCongViec);
        etNoiDung = findViewById(R.id.etNoiDung);

        btnDate = findViewById(R.id.btnDate);
        btnTime = findViewById(R.id.btnTime);
        btnNhap = findViewById(R.id.btnNhap);

        lvCongViec = findViewById(R.id.lvCongViec);
        // Set adapter
        adapterJob = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, arrayJob);
        lvCongViec.setAdapter(adapterJob);
    }

    private void getDefaultInfor() {
        cal = Calendar.getInstance();
        dateFinish = cal.getTime();
        timeFinish = cal.getTime();
    }

    private void addEventFormWidgets(){
//        set event for view
        btnDate.setOnClickListener(new MyButtonEvent());
        btnTime.setOnClickListener(new MyButtonEvent());
        btnNhap.setOnClickListener(new MyButtonEvent());
        lvCongViec.setOnItemClickListener(new MyListViewEvent());
        lvCongViec.setOnItemLongClickListener(new MyListViewEvent());
    }

    private class MyButtonEvent implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            int viewId = v.getId();

            if (viewId == R.id.btnDate) {
                showDatePickerDialog();
            } else if (viewId == R.id.btnTime) {
                showTimePickerDialog();
            } else if (viewId == R.id.btnNhap) {
                processAddJob();
            }
        }

    }

    private class MyListViewEvent implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener{

        @Override
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
            Toast.makeText(bai412.this, arrayJob.get(i).getDesc(), Toast.LENGTH_LONG).show();
        }

        @Override
        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
            arrayJob.remove(i);
            adapterJob.notifyDataSetChanged();
            return false;
        }
    }

    private void showDatePickerDialog(){
        // Get current date
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        // Create DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this, // Replace 'this' with your Activity or Fragment context
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Handle selected date
                        String selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                        // Do something with the selected date (e.g., display it in a TextView)
                        tvNgayHT.setText(selectedDate);
                    }
                },
                year, month, day);

        // Show the dialog
        datePickerDialog.show();
    }

    private void showTimePickerDialog() {
        // Get the current time
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);

        // Create a new instance of TimePickerDialog
        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this, // Context (usually your Activity or Fragment)
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        // Handle the selected time
                        String selectedTime = String.format("%02d:%02d", hourOfDay, minute);
                        // Do something with the selected time, e.g., update a TextView
                        tvGioHT.setText(selectedTime);
                    }
                },
                hour, // Initial hour
                minute, // Initial minute
                false // 24-hour format (true) or AM/PM format (false)
        );

        // Show the dialog
        timePickerDialog.show();
    }

    public void processAddJob() {
        String title = etCongViec.getText().toString();
        String desc = etNoiDung.getText().toString();
        JobInWeek job = new JobInWeek(title, desc, dateFinish, timeFinish);
        arrayJob.add(job);adapterJob.notifyDataSetChanged();
        etCongViec.setText("");
        etNoiDung.setText("");
        tvNgayHT.setText("");
        etCongViec.requestFocus();
    }
}
