package com.example.bai410_412;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class bai410 extends AppCompatActivity {
    Spinner spinThanhPho;
    TextView txtHienThi;
    ArrayList<String> listThanhPho = new ArrayList<>();
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bai410);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listThanhPho.add("Hà Nội");
        listThanhPho.add("Hồ Chí Minh");
        listThanhPho.add("Đà Nẵng");
        listThanhPho.add("Cần Thơ");

        spinThanhPho = findViewById(R.id.spinThanhPho);
        txtHienThi = findViewById(R.id.txtHienThi);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listThanhPho);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinThanhPho.setAdapter(adapter);

        spinThanhPho.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                txtHienThi.setText(listThanhPho.get(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
}