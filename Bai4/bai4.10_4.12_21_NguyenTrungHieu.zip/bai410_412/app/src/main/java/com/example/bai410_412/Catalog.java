package com.example.bai410_412;

import androidx.annotation.NonNull;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Catalog {
    private String id;
    private String name;
    private ArrayList<Product> goods = new ArrayList<>();

    public Catalog(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public Catalog() {}

    public boolean isEmpty(Product p) {
        for(Product product : goods) {
            if(product.getId().trim().equalsIgnoreCase(p.getId().trim())) return true;
        }
        return false;
    }

    public boolean add(Product p) {
        if(isEmpty(p)) return false;
        goods.add(p);
        return true;
    }

    public ArrayList<Product> getGoods() {
        return goods;
    }

    @NonNull
    @Override
    public String toString() {
        return id + " - " + name;
    }
}
