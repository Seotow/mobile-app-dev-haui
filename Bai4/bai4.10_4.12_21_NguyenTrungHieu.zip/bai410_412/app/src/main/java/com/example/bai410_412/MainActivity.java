package com.example.bai410_412;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button bai410btn = findViewById(R.id.bai410btn);
        Button bai411btn = findViewById(R.id.bai411btn);
        Button bai412btn = findViewById(R.id.bai412btn);


        bai410btn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, bai410.class));
        });
        bai411btn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, bai411.class));
        });
        bai412btn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, bai412.class));
        });

    }
}