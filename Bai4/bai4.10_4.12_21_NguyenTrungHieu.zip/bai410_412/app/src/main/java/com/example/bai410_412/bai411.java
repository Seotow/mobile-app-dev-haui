package com.example.bai410_412;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class bai411 extends AppCompatActivity {
    Spinner spDanhMuc;
    EditText etMaSp, etTenSp, etSoLuong;
    ListView lvSanPham;
    ArrayList<Catalog> arraySpinner = new ArrayList<>();
    ArrayAdapter<Catalog> adapterSpinner = null;

    ArrayList<Product> arrayProduct = new ArrayList<>();
    ArrayAdapter<Product> adapterProduct = null;

    Button btnNhapSP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bai411);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        getWidgetControl();
        Catalog cat1 = new Catalog("1","SamSung");
        Catalog cat2 = new Catalog("2","Nokia");
        Catalog cat3 = new Catalog("3","IPAD");
        Catalog cat4 = new Catalog("4","HTC");
        arraySpinner.add(cat1);
        arraySpinner.add(cat2);
        arraySpinner.add(cat3);
        arraySpinner.add(cat4);

        Product p1 = new Product("SA","SamSung",10);
        Product p2 = new Product("NO1","Nokia",20);
        Product p3 = new Product("IP1","IPAD",30);
        Product p4 = new Product("HT1","HTC",40);
        arrayProduct.add(p1);
        arrayProduct.add(p2);
        arrayProduct.add(p3);
        arrayProduct.add(p4);

        adapterSpinner.notifyDataSetChanged();
        addEventsFromWidgets();


    }

    private void getWidgetControl() {
        spDanhMuc = findViewById(R.id.spDanhMuc);
        etMaSp = findViewById(R.id.etMaSp);
        etTenSp = findViewById(R.id.etTenSp);
        etSoLuong = findViewById(R.id.etSoLuong);
        lvSanPham = findViewById(R.id.lvSanPham);
        btnNhapSP = findViewById(R.id.btnNhapSP);

        adapterSpinner = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arraySpinner);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDanhMuc.setAdapter(adapterSpinner);

    }

    private void addEventsFromWidgets() {
        spDanhMuc.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            String prefix = "";
            List<Product> listFiltered = new ArrayList<>();
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0: //Samsung
                        prefix = "SA";
                        listFiltered = arrayProduct.stream()
                                .filter(product -> product.getId().startsWith(prefix))
                                .collect(Collectors.toList());
                        break;
                    case 1: //Nokia
                        prefix = "NO";
                        listFiltered = arrayProduct.stream()
                                .filter(product -> product.getId().startsWith(prefix))
                                .collect(Collectors.toList());
                        break;
                    case 2: //IP
                        prefix = "IP";
                        listFiltered = arrayProduct.stream()
                                .filter(product -> product.getId().startsWith(prefix))
                                .collect(Collectors.toList());
                        break;
                    case 3: //HTC
                        prefix = "HT";
                        listFiltered = arrayProduct.stream()
                                .filter(product -> product.getId().startsWith(prefix))
                                .collect(Collectors.toList());
                        break;
                    default:
                        break;
                }

                adapterProduct = new ArrayAdapter<>(bai411.this, android.R.layout.simple_list_item_1, listFiltered);
                lvSanPham.setAdapter(adapterProduct);
                adapterProduct.notifyDataSetChanged();

                btnNhapSP.setOnClickListener(view1 -> {
                    String productId = prefix + etMaSp.getText().toString();
                    String productName = etTenSp.getText().toString();
                    int quantity = Integer.parseInt(etSoLuong.getText().toString());

                    if(productId.isEmpty() || productName.isEmpty() || quantity == 0) { return; }


                    Product product = new Product(productId, productName, quantity);
                    arrayProduct.add(product);
                    listFiltered.add(product);
                    adapterProduct.notifyDataSetChanged();
                    //clear text and apply change to view
                    adapterView.setSelection(i);

                });


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                adapterView.setSelected(true);
            }
        });
    }
}