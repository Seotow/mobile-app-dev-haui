package com.example.bai41_46;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button bai41btn = findViewById(R.id.bai41btn);
        Button bai42btn = findViewById(R.id.bai42btn);
        Button bai43btn = findViewById(R.id.bai43btn);
        Button bai44btn = findViewById(R.id.bai44btn);
        Button bai45btn = findViewById(R.id.bai45btn);
        Button bai46btn = findViewById(R.id.bai46btn);


        bai41btn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, bai41.class));
        });
        bai42btn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, bai42.class));
        });
        bai43btn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, bai43.class));
        });
        bai44btn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, bai44.class));
        });
        bai45btn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, bai45.class));
        });
        bai46btn.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, bai46.class));
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // TODO Auto-generated method stub
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}