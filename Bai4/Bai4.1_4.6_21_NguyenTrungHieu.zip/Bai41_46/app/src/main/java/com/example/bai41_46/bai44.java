package com.example.bai41_46;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class bai44 extends AppCompatActivity {

    private EditText etName, etCmnd, etAdditionalInfo;
    private RadioGroup rgDegree;
    private CheckBox cbDocSach, cbDocBao, cbDocCode;
    private Button btnSubmit;
    private TextView infor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai44);

        etName = findViewById(R.id.etName);
        etCmnd = findViewById(R.id.etCmnd);
        etAdditionalInfo = findViewById(R.id.etAdditionalInfo);
        rgDegree = findViewById(R.id.rgDegree);
        cbDocSach = findViewById(R.id.cbDocSach);
        cbDocBao = findViewById(R.id.cbDocBao);
        cbDocCode = findViewById(R.id.cbDocCode);
        btnSubmit = findViewById(R.id.btnSubmit);
        infor = findViewById(R.id.infor);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitInfo();
            }
        });
    }

    private void submitInfo() {
        String name = etName.getText().toString();
        String cmnd = etCmnd.getText().toString();
        String additionalInfo = etAdditionalInfo.getText().toString();


        String degree = "";
        int selectedId = rgDegree.getCheckedRadioButtonId();
        if (selectedId == R.id.rbTrungCap) {
            degree = "Trung Cấp";
        } else if (selectedId == R.id.rbCaoDang) {
            degree = "Cao Đẳng";
        } else if (selectedId == R.id.rbDaiHoc) {
            degree = "Đại Học";
        } else {
            degree = "No degree selected";  // Handle the case where nothing is selected
        }

        String hobbies = "";
        if (cbDocSach.isChecked()) hobbies += "Đọc Sách, ";
        if (cbDocBao.isChecked()) hobbies += "Đọc Báo, ";
        if (cbDocCode.isChecked()) hobbies += "Đọc Code, ";

        infor.setText("Họ tên: " + name + "\nCMND: " + cmnd + "\nBằng cấp: " + degree + "\nSở thích: " + hobbies + "\nThông tin bổ sung: " + additionalInfo);
    }
}