package com.example.bai41_46;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class bai46 extends AppCompatActivity {

    private EditText etMaNv, etTenNv;
    private RadioGroup rgLoaiNv;
    private CheckBox cbLuuThongTin;
    private Button inputNV;
    private ListView lvNhanVien;
    private ArrayList<Employee> employeeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai46);

        etMaNv = findViewById(R.id.etMaNv);
        etTenNv = findViewById(R.id.etTenNv);
        rgLoaiNv = findViewById(R.id.rgLoaiNv);
        cbLuuThongTin = findViewById(R.id.cbLuuThongTin);
        inputNV = findViewById(R.id.inputNV);
        lvNhanVien = findViewById(R.id.lvNhanVien);
        employeeList = new ArrayList<>();

        inputNV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addEmployee();
                // Clear EditText fields
                etMaNv.setText("");
                etTenNv.setText("");
                rgLoaiNv.check(R.id.rbThoiVu);
            }
        });
    }

    private void addEmployee() {
        String maNv = etMaNv.getText().toString();
        String tenNv = etTenNv.getText().toString();
        String loaiNv = rgLoaiNv.getCheckedRadioButtonId() == R.id.rbChinhThuc ? "Chính thức" : "Thời vụ";

        if (cbLuuThongTin.isChecked()) {

            if (loaiNv.equals("Chính thức")){
                EmployeeFullTime employeeInfo = new EmployeeFullTime(maNv, tenNv);
                employeeList.add(employeeInfo);
            }
            else {
                EmployeeParttime employeeInfo = new EmployeeParttime(maNv, tenNv);
                employeeList.add(employeeInfo);
            }

            // Update ListView with employeeList (adapter required here)
            ArrayAdapter<Employee> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, employeeList);
            lvNhanVien.setAdapter(adapter);
            // Clear EditText fields
            etMaNv.setText("");
            etTenNv.setText("");
            rgLoaiNv.clearCheck();

        }
    }
}