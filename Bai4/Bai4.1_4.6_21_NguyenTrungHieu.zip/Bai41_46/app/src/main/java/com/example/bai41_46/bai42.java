package com.example.bai41_46;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class bai42 extends AppCompatActivity {

    private EditText namDuong;
    private TextView namAm;
    private Button convertButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai42);

        namDuong = findViewById(R.id.namDuong);
        namAm = findViewById(R.id.namAm);
        convertButton = findViewById(R.id.convertButton);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String yearInput = namDuong.getText().toString();
                if (!yearInput.isEmpty()) {
                    int year = Integer.parseInt(yearInput);
                    String lunarYear = convertToLunar(year);
                    namAm.setText(lunarYear);
                }
            }
        });
    }

    private String convertToLunar(int year) {
        // Placeholder conversion logic; implement actual conversion here
        switch (year % 12) {
            case 0: return "Thân";
            case 1: return "Dậu";
            case 2: return "Tuất";
            case 3: return "Hợi";
            case 4: return "Tý";
            case 5: return "Sửu";
            case 6: return "Dần";
            case 7: return "Mão";
            case 8: return "Thìn";
            case 9: return "Tỵ";
            case 10: return "Ngọ";
            case 11: return "Mùi";
            default: return "Unknown";
        }
    }
}