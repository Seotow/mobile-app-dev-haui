package com.example.bai41_46;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class bai43 extends AppCompatActivity {

    private EditText nameEditText, heightEditText, weightEditText;
    private TextView bmiResultTextView, diagnosisTextView;
    private Button calculateButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai43);

        nameEditText = findViewById(R.id.nameEditText);
        heightEditText = findViewById(R.id.heightEditText);
        weightEditText = findViewById(R.id.weightEditText);
        bmiResultTextView = findViewById(R.id.bmiResultTextView);
        diagnosisTextView = findViewById(R.id.diagnosisTextView);
        calculateButton = findViewById(R.id.calculateButton);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateBMI();
            }
        });
    }

    private void calculateBMI() {
        String heightInput = heightEditText.getText().toString();
        String weightInput = weightEditText.getText().toString();

        if (!heightInput.isEmpty() && !weightInput.isEmpty()) {
            float height = Float.parseFloat(heightInput);
            float weight = Float.parseFloat(weightInput);
            float bmi = weight / (height * height);

            bmiResultTextView.setText(String.format("%.2f", bmi));

            if (bmi < 18.5) {
                diagnosisTextView.setText("Bạn thiếu cân");
            } else if (bmi >= 18.5 && bmi < 24.9) {
                diagnosisTextView.setText("Bạn bình thường");
            } else {
                diagnosisTextView.setText("Bạn thừa cân");
            }
        }
    }
}