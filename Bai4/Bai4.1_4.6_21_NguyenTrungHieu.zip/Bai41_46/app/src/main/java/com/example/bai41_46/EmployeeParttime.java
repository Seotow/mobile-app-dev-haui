package com.example.bai41_46;

import androidx.annotation.NonNull;

public class EmployeeParttime extends Employee{
    @Override
    public double salaryCalc() {
        return 150;
    }


    public EmployeeParttime() {
        super();
    }

    public EmployeeParttime(String id, String name) {
        super(id, name);
    }

    @NonNull
    @Override
    public String toString() {
        return "Part time: " + super.toString() + "\tLương: " + this.salaryCalc();
    }
}

