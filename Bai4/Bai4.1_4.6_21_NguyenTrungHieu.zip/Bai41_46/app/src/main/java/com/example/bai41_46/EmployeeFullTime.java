package com.example.bai41_46;

import androidx.annotation.NonNull;

public class EmployeeFullTime extends Employee{
    @Override
    public double salaryCalc() {
        return 500;
    }

    public EmployeeFullTime() {
        super();
    }

    public EmployeeFullTime(String id, String name) {
        super(id, name);
    }

    @NonNull
    @Override
    public String toString() {
        return "Full time: " + super.toString() + "\tLương: " + this.salaryCalc();
    }
}
