package com.example.bai81;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText etName, etPassword;
    CheckBox cbSave;
    Button btnInput, btnOut;
    String tenThongTinDangNhap = "login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etName = findViewById(R.id.etName);
        etPassword = findViewById(R.id.etPassword);
        cbSave = findViewById(R.id.cbSave);
        btnInput = findViewById(R.id.btnInput);
        btnOut = findViewById(R.id.btnOut);

        btnInput.setOnClickListener(v -> {
            saveLoginState();
        });

        btnOut.setOnClickListener(v -> {
            finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    public void saveLoginState() {
        SharedPreferences.Editor editor = getSharedPreferences(tenThongTinDangNhap, MODE_PRIVATE).edit();
        editor.putString("ten", etName.getText().toString());
        editor.putString("matKhau", etPassword.getText().toString());
        editor.putBoolean("save", cbSave.isChecked());
        editor.apply();

    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences = getSharedPreferences(tenThongTinDangNhap, MODE_PRIVATE);
        String ten = sharedPreferences.getString("ten", "");
        String matKhau = sharedPreferences.getString("matKhau", "");
        boolean save = sharedPreferences.getBoolean("save", false);
        if(save) {
            etName.setText(ten);
            etPassword.setText(matKhau);
            cbSave.setChecked(true);
        }
    }
}